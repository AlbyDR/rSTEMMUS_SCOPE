config_file = "../stemmus_scope/input/ZA-Kru_2023-11-16-0728/ZA-Kru_2023-11-16-0728_config.txt";
run_mode = "finalize";
STEMMUS_SCOPE_exe(config_file, run_mode);
